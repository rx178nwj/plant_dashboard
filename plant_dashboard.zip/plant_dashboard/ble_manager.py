# plant_dashboard/ble_manager.py

import asyncio
import logging
from bleak import BleakClient, BleakScanner
from bleak.exc import BleakError

import config

# --- UUID定義 ---
PLANT_SERVICE_UUID = config.TARGET_SERVICE_UUID
CMD_CHAR_UUID = "6a3b2c1d-4e5f-6a7b-8c9d-e0f123456791"
RES_CHAR_UUID = "6a3b2c1d-4e5f-6a7b-8c9d-e0f123456792"
SWITCHBOT_LEGACY_METER_UUID = "cba20d00-224d-11e6-9fb8-0002a5d5c51b"
SWITCHBOT_COMMON_SERVICE_UUID = "0000fd3d-0000-1000-8000-00805f9b34fb"

# --- コマンド定義 ---
CMD_GET_SENSOR_DATA = b'\x01'
CMD_GET_SWITCH_STATUS = b'\x0b' # スイッチ状態取得コマンドを追加

logger = logging.getLogger(__name__)

class PlantDeviceBLE:
    # (connect, disconnect, ensure_connection は変更なし)
    def __init__(self, mac_address, device_id):
        self.mac_address = mac_address
        self.device_id = device_id
        self.client = BleakClient(mac_address)
        self.is_connected = False
    async def connect(self):
        logger.info(f"[{self.device_id}] Attempting to connect to {self.mac_address}...")
        try:
            await self.client.connect()
            self.is_connected = self.client.is_connected
            return True
        except BleakError as e:
            logger.error(f"[{self.device_id}] Failed to connect: {e}")
            self.is_connected = False
            return False
    async def disconnect(self):
        if self.is_connected:
            try:
                await self.client.disconnect()
            except BleakError as e:
                logger.error(f"[{self.device_id}] Error during disconnection: {e}")
        self.is_connected = False
    async def ensure_connection(self):
        if self.client.is_connected:
            return True
        logger.info(f"[{self.device_id}] Connection lost. Attempting to reconnect...")
        self.is_connected = False
        for attempt in range(config.RECONNECT_ATTEMPTS):
            delay = config.RECONNECT_DELAY_BASE ** attempt
            await asyncio.sleep(delay)
            if await self.connect():
                return True
        logger.error(f"[{self.device_id}] Failed to reconnect after {config.RECONNECT_ATTEMPTS} attempts.")
        return False
    
    async def get_sensor_data(self):
        """センサーデータとスイッチ状態の両方を取得する"""
        if not self.is_connected:
            return None

        final_data = {}
        
        try:
            # 1. センサーデータを取得
            await self.client.write_gatt_char(CMD_CHAR_UUID, CMD_GET_SENSOR_DATA, response=True)
            sensor_response = await self.client.read_gatt_char(RES_CHAR_UUID)
            
            if len(sensor_response) >= 11:
                final_data.update({
                    'temperature': int.from_bytes(sensor_response[0:2], 'little', signed=True) / 100.0,
                    'humidity': int.from_bytes(sensor_response[2:4], 'little') / 100.0,
                    'light_lux': int.from_bytes(sensor_response[4:8], 'little'),
                    'soil_moisture': int.from_bytes(sensor_response[8:10], 'little'),
                    'battery_level': int(sensor_response[10])
                })
            else:
                logger.warning(f"[{self.device_id}] Invalid sensor response length: {len(sensor_response)}")

            # 2. スイッチ状態を取得
            await self.client.write_gatt_char(CMD_CHAR_UUID, CMD_GET_SWITCH_STATUS, response=True)
            switch_response = await self.client.read_gatt_char(RES_CHAR_UUID)

            if len(switch_response) >= 1:
                final_data['button_pressed'] = bool(switch_response[0])
            else:
                logger.warning(f"[{self.device_id}] Invalid switch response length: {len(switch_response)}")
                final_data['button_pressed'] = False

            logger.debug(f"[{self.device_id}] Received combined data: {final_data}")
            return final_data if final_data else None

        except BleakError as e:
            logger.error(f"[{self.device_id}] Failed to get data: {e}")
            self.is_connected = False
            return None

def _parse_switchbot_adv_data(adv_data):
    """
    SwitchBotデバイスのアドバタイズメントデータを解析し、
    デバイスタイプとセンサーデータを返す。
    """
    if SWITCHBOT_COMMON_SERVICE_UUID in adv_data.service_data:
        service_data = adv_data.service_data[SWITCHBOT_COMMON_SERVICE_UUID]
        model = service_data[0] & 0b01111111
        battery = service_data[1] & 0b01111111
        
        # モデル 'i' (0x69) -> 温湿度計プラス
        if model == 0x69:
            temperature = (service_data[3] & 0b00001111) / 10.0 + (service_data[4] & 0b01111111)
            if not (service_data[4] & 0b10000000):
                temperature = -temperature
            humidity = service_data[5] & 0b01111111
            return {
                'type': 'switchbot_meter_plus',
                'data': {'temperature': temperature, 'humidity': humidity, 'battery_level': battery}
            }
        
        # モデル 'c' (0x63) -> CO2センサー
        elif model == 0x63:
            temperature = (service_data[5] & 0b01111111) + (service_data[4] / 10.0)
            humidity = service_data[6] & 0b01111111
            co2 = int.from_bytes(service_data[7:9], 'little')
            return {
                'type': 'switchbot_co2_meter',
                'data': {'temperature': temperature, 'humidity': humidity, 'co2': co2, 'battery_level': battery}
            }
        
    elif SWITCHBOT_LEGACY_METER_UUID in adv_data.service_data:
        service_data = adv_data.service_data[SWITCHBOT_LEGACY_METER_UUID]
        battery = service_data[2] & 0b01111111
        is_temp_above_freezing = service_data[4] & 0b10000000
        temp_val = service_data[4] & 0b01111111
        temperature = temp_val + (service_data[3] / 10.0)
        if not is_temp_above_freezing:
            temperature = -temperature
        humidity = service_data[5] & 0b01111111
        return {
            'type': 'switchbot_meter',
            'data': {'temperature': temperature, 'humidity': humidity, 'battery_level': battery}
        }
        
    return None

async def scan_devices():
    logger.info("Scanning for devices...")
    found_devices = []
    try:
        devices = await BleakScanner.discover(timeout=10.0, return_adv=True)
        for address, (device, adv_data) in devices.items():
            if PLANT_SERVICE_UUID in adv_data.service_uuids:
                found_devices.append({'address': device.address, 'name': device.name or 'Unknown Plant Sensor', 'type': 'plant_sensor', 'rssi': device.rssi})
                continue
            switchbot_info = _parse_switchbot_adv_data(adv_data)
            if switchbot_info:
                device_name_map = {'switchbot_meter': 'SwitchBot Meter', 'switchbot_meter_plus': 'SwitchBot Meter Plus', 'switchbot_co2_meter': 'SwitchBot CO2 Meter'}
                found_devices.append({'address': device.address, 'name': device.name or device_name_map.get(switchbot_info['type'], 'Unknown SwitchBot'), 'type': switchbot_info['type'], 'rssi': device.rssi, 'data': switchbot_info.get('data')})
    except BleakError as e:
        logger.error(f"Error while scanning: {e}")
    return found_devices

async def get_switchbot_adv_data(mac_address: str):
    """
    指定されたMACアドレスのSwitchBotデバイスからアドバタイズデータを取得する。
    find_device_by_address の代わりに discover を使用して、データ取得の信頼性を向上させる。
    """
    logger.debug(f"Scanning for 5 seconds to find {mac_address}...")
    try:
        # 5秒間スキャンして、受信したすべてのアドバタイズメントを取得
        devices = await BleakScanner.discover(timeout=5.0, return_adv=True)
        
        # スキャン結果から目的のMACアドレスのデバイス情報を取得
        target_device_info = devices.get(mac_address.upper()) # MACアドレスは大文字で比較

        if target_device_info:
            _device, adv_data = target_device_info
            if adv_data:
                # アドバタイズデータがあれば解析を試みる
                switchbot_info = _parse_switchbot_adv_data(adv_data)
                if switchbot_info:
                    logger.debug(f"Successfully parsed data for {mac_address}")
                    return switchbot_info.get('data')
                else:
                    # データはあるが、SwitchBotの形式ではなかった場合
                    logger.warning(f"Found {mac_address}, but could not parse SwitchBot data from its advertisement.")
            else:
                # デバイスは見つかったが、アドバタイズデータが空だった場合
                logger.warning(f"Found {mac_address} but it had no advertisement data.")
        else:
            # スキャン時間内にデバイスが見つからなかった場合
            logger.warning(f"Device {mac_address} not found during the 5-second scan.")
        
        return None # データが取得できなかった場合はNoneを返す

    except BleakError as e:
        logger.error(f"A BleakError occurred while scanning for {mac_address}: {e}")
        return None
    except Exception as e:
        logger.error(f"An unexpected error occurred in get_switchbot_adv_data for {mac_address}: {e}")
        return None
